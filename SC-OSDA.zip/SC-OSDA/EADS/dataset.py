import os
import cv2
import numpy as np
import transform
from torch.utils.data import Dataset


mean_rgb = np.array([[[]]])*255
std_rgb = np.array([[[]]])*255


class Data(Dataset):
    def __init__(self, root, mode='train'):
        self.samples = []
        lines = os.listdir(os.path.join(root, 'GT'))
        self.mode = mode
        for line in lines:
            rgbpath = os.path.join(root, 'RGB', line)
            maskpath = os.path.join(root, 'GT', line)
            edgepath = os.path.join(root, 'EDGE', line)
            self.samples.append([rgbpath, maskpath, edgepath])

        if mode == 'train':
            self.transform = transform.Compose(transform.Normalize(mean1=mean_rgb, std1=std_rgb),
                                                transform.Resize(352, 352),
                                                transform.RandomHorizontalFlip(),
                                                transform.ToTensor())

        elif mode == 'test':
            self.transform = transform.Compose( transform.Normalize(mean1=mean_rgb, std1=std_rgb),
                                                transform.Resize(352, 352),
                                                transform.ToTensor())
        else:
            raise ValueError

    def __getitem__(self, idx):
        rgbpath, maskpath, edgepath = self.samples[idx]

        rgb = cv2.imread(rgbpath).astype(np.float32)
        mask = cv2.imread(maskpath).astype(np.float32)
        edge = cv2.imread(edgepath).astype(np.float32)
        H, W, C = mask.shape
        rgb, mask, edge = self.transform(rgb, mask, edge)

        return rgb, mask, edge, (H, W), maskpath.split('/')[-1]

    def __len__(self):
        return len(self.samples)
