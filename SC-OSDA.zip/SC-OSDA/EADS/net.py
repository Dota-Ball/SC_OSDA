import torch
from torch import nn
import torch.nn.functional as F
import mix_transformer


def convblock(in_, out_, ks, st, pad):
    return nn.Sequential(
        nn.Conv2d(in_, out_, ks, st, pad),
        nn.BatchNorm2d(out_),
        nn.ReLU(inplace=True)
    )


class Fuse(nn.Module):
    def __init__(self, ch_1, ch_2):
        super(Fuse, self).__init__()

        self.conv_pre = convblock(ch_1, ch_2, 3, 1, 1)
        self.conv_fuse = nn.Sequential(
            nn.Conv2d(ch_2, ch_2 // 4, 3, 1, 1),
            nn.BatchNorm2d(ch_2 // 4),
            nn.ReLU(),
            nn.Conv2d(ch_2 // 4, ch_2, 3, 1, 1),
            nn.BatchNorm2d(ch_2),
            nn.ReLU()
        )

    def forward(self, rgb, pre):
        cur_size = rgb.size()[2:]
        pre = self.conv_pre(F.interpolate(pre, cur_size, mode='bilinear', align_corners=True))
        fes = pre + rgb

        return fes


class EDGE(nn.Module):

    def __init__(self):
        super(EDGE, self).__init__()

        self.conv2 = nn.Sequential(
            nn.Conv2d(128, 128, kernel_size=3, dilation=1, padding=1), nn.BatchNorm2d(128), nn.PReLU()
        )
        self.conv3 = nn.Sequential(
            nn.Conv2d(320, 128, kernel_size=3, dilation=1, padding=1), nn.BatchNorm2d(128), nn.PReLU()
        )
        self.conv4 = nn.Sequential(
            nn.Conv2d(512, 128, kernel_size=1), nn.BatchNorm2d(128), nn.PReLU()
        )

        self.fuse = nn.Sequential(
            nn.Conv2d(3 * 128, 512, kernel_size=1), nn.BatchNorm2d(512), nn.PReLU()
        )

    def forward(self, x):
        xsize = x[3].size()[2:]

        conv2 = self.conv2(x[1])
        conv3 = self.conv3(x[2])
        conv4 = self.conv4(x[3])

        conv2 = F.interpolate(conv2, xsize, mode='bilinear', align_corners=True)
        conv3 = F.interpolate(conv3, xsize, mode='bilinear', align_corners=True)

        x_fuse = self.fuse(torch.cat((conv2, conv3, conv4), 1))

        return x_fuse


class Decoder(nn.Module):
    def __init__(self):
        super(Decoder, self).__init__()

        self.edge = EDGE()
        self.f4 = Fuse(512, 512)
        self.f3 = Fuse(512, 320)
        self.f2 = Fuse(320, 128)
        self.f1 = Fuse(128, 64)

        self.s_seg = nn.Conv2d(64, 1, 1, 1, 0)
        self.s_edge = nn.Conv2d(512, 1, 1, 1, 0)

    def forward(self, rgb):

        edge = self.edge(rgb)

        f4 = self.f4(rgb[3], edge)
        f3 = self.f3(rgb[2], f4)
        f2 = self.f2(rgb[1], f3)
        f1 = self.f1(rgb[0], f2)

        s_seg = self.s_seg(f1)
        s_edge = self.s_edge(edge)

        return s_seg, s_edge


class Segformer(nn.Module):
    def __init__(self, backbone, pretrained=None):
        super().__init__()

        self.encoder = getattr(mix_transformer, backbone)()
        if pretrained:
            state_dict = torch.load(backbone + '.pth')
            state_dict.pop('head.weight')
            state_dict.pop('head.bias')
            self.encoder.load_state_dict(state_dict, )

    def forward(self):
        model = Segformer('mit_b3', pretrained=True)
        return model


class SCNet(nn.Module):
    def __init__(self, backbone="mit_b3", pretrained=True):
        super(SCNet, self).__init__()

        net = Segformer(backbone, pretrained)
        self.rgb_encoder = net.encoder
        self.decoder = Decoder()
        self.sigmoid = nn.Sigmoid()

    def forward(self, rgb):
        # rgb
        B = rgb.shape[0]
        Hig = rgb.shape[2]
        rgb_f = []

        # stage 1
        x, H, W = self.rgb_encoder.patch_embed1(rgb)
        for i, blk in enumerate(self.rgb_encoder.block1):
            x = blk(x, H, W)
        x = self.rgb_encoder.norm1(x)
        x = x.reshape(B, H, W, -1).permute(0, 3, 1, 2).contiguous()
        rgb_f.append(x)

        # stage 2
        x, H, W = self.rgb_encoder.patch_embed2(x)
        for i, blk in enumerate(self.rgb_encoder.block2):
            x = blk(x, H, W)
        x = self.rgb_encoder.norm2(x)
        x = x.reshape(B, H, W, -1).permute(0, 3, 1, 2).contiguous()
        rgb_f.append(x)

        # stage 3
        x, H, W = self.rgb_encoder.patch_embed3(x)
        for i, blk in enumerate(self.rgb_encoder.block3):
            x = blk(x, H, W)
        x = self.rgb_encoder.norm3(x)
        x = x.reshape(B, H, W, -1).permute(0, 3, 1, 2).contiguous()
        rgb_f.append(x)

        # stage 4
        x, H, W = self.rgb_encoder.patch_embed4(x)
        for i, blk in enumerate(self.rgb_encoder.block4):
            x = blk(x, H, W)
        x = self.rgb_encoder.norm4(x)
        x = x.reshape(B, H, W, -1).permute(0, 3, 1, 2).contiguous()
        rgb_f.append(x)

        s_seg, s_edge = self.decoder(rgb_f)

        return s_seg, s_edge
