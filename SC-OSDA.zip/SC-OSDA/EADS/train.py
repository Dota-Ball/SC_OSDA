import os
from net import SCnet
import torch
import random
import numpy as np
from torch.autograd import Variable
import torch.optim as optim
from torch.utils.data import DataLoader, ConcatDataset
from dataset import Data
from data_prefetcher import DataPrefetchers
from torch.nn import functional as F


os.environ["CUDA_VISIBLE_DEVICES"] = "0"


def loss(seg, label, edge, edge_label):
    seg = F.interpolate(seg, label.shape[2:], mode='bilinear', align_corners=True)
    edge = F.interpolate(edge, label.shape[2:], mode='bilinear', align_corners=True)

    seg_loss = F.binary_cross_entropy_with_logits(seg, label, reduction='mean')
    edge_loss = F.binary_cross_entropy_with_logits(edge, label, reduction='mean')

    return seg_loss + 0.5 * edge_loss


if __name__ == '__main__':
    random.seed(42)
    np.random.seed(42)
    torch.manual_seed(42)
    torch.cuda.manual_seed(42)
    torch.cuda.manual_seed_all(42)
    # dataset

    data_root = '/datadir/'

    save_path = './model'
    lr = 0.001
    batch_size = 8
    epoch = 80

    #  init net
    net = SCnet().cuda()
    optimizer = optim.SGD(filter(lambda p: p.requires_grad, net.parameters()), lr=lr, weight_decay=0.0005, momentum=0.9)
    net.train()

    for epochi in range(1, epoch + 1):

        optimizer = optim.SGD(filter(lambda p: p.requires_grad, net.parameters()), lr=lr, weight_decay=0.0005,
                                  momentum=0.9)

        rail_data = Data(data_root)
        train_dataset = rail_data
        train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=4)
        prefetcher = DataPrefetcher(train_loader)
        rgb, label, edge_label = prefetcher.next()

        iter_num = len(train_loader) - 1

        train_seg_loss = 0
        i = 0

        for j in range(iter_num):
            i += 1

            seg, edge = net(rgb)

            train_loss = loss(seg, label, edge, edge_label,)
            train_seg_loss += train_loss.data
            train_loss.backward()

            optimizer.step()
            optimizer.zero_grad()

            if i % 100 == 0:
                print('epoch: [%2d/%2d], iter: [%5d/%5d]  ||  train_loss : %5.4f  || lr:%6.5f' % (
                    epochi, epoch, i, iter_num, train_seg_loss / 100, lr))


            rgb, label, edge_label = prefetcher.next()

        if  epochi % 10 == 0:
            torch.save(net.state_dict(), '%s/epoch_%d.pth' % (save_path, epochi))

    torch.save(net.state_dict(), '%s/final.pth' % (save_path))
