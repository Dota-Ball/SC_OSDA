import os
from net import Net
import torch
import random
import numpy as np
import torch.optim as optim
from torch.utils.data import DataLoader
from dataset import Data
from data_prefetcher import DataPrefetcher
from torch.nn import functional as F


os.environ["CUDA_VISIBLE_DEVICES"] = "0"


def seg_loss(score1, score2, score3, score4, label, edge, edge_label):
    score1 = F.interpolate(score1, label.shape[2:], mode='bilinear', align_corners=True)
    score2 = F.interpolate(score2, label.shape[2:], mode='bilinear', align_corners=True)
    score3 = F.interpolate(score3, label.shape[2:], mode='bilinear', align_corners=True)
    score4 = F.interpolate(score4, label.shape[2:], mode='bilinear', align_corners=True)

    edge = F.interpolate(edge, edge_label.shape[2:], mode='bilinear', align_corners=True)

    loss1 = F.binary_cross_entropy_with_logits(score1, label, reduction='mean')
    loss2 = F.binary_cross_entropy_with_logits(score2, label, reduction='mean')
    loss3 = F.binary_cross_entropy_with_logits(score3, label, reduction='mean')
    loss4 = F.binary_cross_entropy_with_logits(score4, label, reduction='mean')

    edge_loss = F.binary_cross_entropy_with_logits(edge, label, reduction='mean')

    return loss1 + loss2 + loss3 + loss4 + edge_loss


if __name__ == '__main__':
    random.seed(118)
    np.random.seed(118)
    torch.manual_seed(118)
    torch.cuda.manual_seed(118)
    torch.cuda.manual_seed_all(118)
    # dataset

    data_root = ''
    save_path = './'
    if not os.path.exists(save_path): os.mkdir(save_path)
    lr = 0.001
    batch_size = 8
    epoch = 120
    data = Data(data_root)
    net = Net().cuda()
    optimizer = optim.SGD(filter(lambda p: p.requires_grad, net.parameters()), lr=lr, weight_decay=0.0005, momentum=0.9)
    net.train()

    num_params = 0
    for p in net.parameters():
        num_params += p.numel()
    print(num_params)

    for epochi in range(1, epoch + 1):

        train_dataset = data
        train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=4)
        prefetcher = DataPrefetcher(train_loader)
        rgb, label, edge_label = prefetcher.next()

        iter_num = len(train_loader) - 1
        loss_data = 0
        net.zero_grad()
        i = 0

        for j in range(iter_num):
            i += 1

            score1, score2, score3, score4, edge = net(rgb)
            train_loss = seg_loss(score1, score2, score3, score4, label, edge, edge_label)
            loss_data += train_loss.data
            train_loss.backward()

            optimizer.step()
            optimizer.zero_grad()

            if i % 100 == 0:
                print('epoch: [%2d/%2d], iter: [%5d/%5d]  || loss : %5.4f || lr:%6.5f' % (
                    epochi, epoch, i, iter_num,  loss_data / 100, lr))
                loss_data = 0

            rgb, label, edge_label = prefetcher.next()

    torch.save(net.state_dict(), '%s/final.pth' % (save_path))
