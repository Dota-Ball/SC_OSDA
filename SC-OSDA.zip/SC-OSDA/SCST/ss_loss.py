import torch

class SSLoss(torch.nn.Module):
    def __init__(self, scale=0.0625):
        super(SSLoss, self).__init__()
        self.scale=int(1/scale)

    def forward(self,fea1,fea2):
        fea1=torch.nn.AvgPool2d(self.subscale)(fea1)
        fea2=torch.nn.AvgPool2d(self.subscale)(fea2)
        
        b, C, h, w = fea1.size()
        fea1 = fea1.view(b, -1, w*h)
        mat1 = torch.bmm(fea1.permute(0,2,1),fea1)

        b, C, h, w = fea2.size()
        fea2 = fea2.view(b, -1, w*h)
        mat2 = torch.bmm(fea2.permute(0,2,1),fea2)

        L1 = torch.norm(mat2-mat1, 1)

        return L1/((h*w)**2)
